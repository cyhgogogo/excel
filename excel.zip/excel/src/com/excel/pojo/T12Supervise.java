package com.excel.pojo;

public class T12Supervise {
    private String[][] supervise;

    public String[][] getSupervise() {
        return supervise;
    }

    public void setSupervise(String[][] supervise) {
        this.supervise = supervise;
    }
}
