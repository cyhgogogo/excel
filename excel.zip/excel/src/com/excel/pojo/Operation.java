package com.excel.pojo;

//运营表
public class Operation {
    //商业银行运营任务
    private String[][] businessBankOperation;

    public String[][] getBusinessBankOperation() {
        return businessBankOperation;
    }

    public void setBusinessBankOperation(String[][] businessBankOperation) {
        this.businessBankOperation = businessBankOperation;
    }
}
