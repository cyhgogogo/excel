package com.excel.pojo;

public class T0_T3_T4 {
    private T0Register t0;
    private T3_T4 t3_t4;

    public T0Register getT0() {
        return t0;
    }

    public void setT0(T0Register t0) {
        this.t0 = t0;
    }

    public T3_T4 getT3_t4() {
        return t3_t4;
    }

    public void setT3_t4(T3_T4 t3_t4) {
        this.t3_t4 = t3_t4;
    }
}
