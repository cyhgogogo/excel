package com.excel.pojo;

//T11 资产负债表
public class T11AssertDebt {
    //资产负债表
    private String[][][] assertDebt;

    public String[][][] getAssertDebt() {
        return assertDebt;
    }

    public void setAssertDebt(String[][][] assertDebt) {
        this.assertDebt = assertDebt;
    }
}
