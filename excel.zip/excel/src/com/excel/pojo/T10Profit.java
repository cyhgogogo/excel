package com.excel.pojo;

//T10损益表
public class T10Profit {
    //T10损益表
    private String[][] profit;

    public String[][] getProfit() {
        return profit;
    }

    public void setProfit(String[][] profit) {
        this.profit = profit;
    }
}
