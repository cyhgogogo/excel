package com.excel.pojo;

//T9现金流表
public class T9Cash {
    //T9现金流表
    private String[][] cashFloat;

    public String[][] getCashFloat() {
        return cashFloat;
    }

    public void setCashFloat(String[][] cashFloat) {
        this.cashFloat = cashFloat;
    }
}
