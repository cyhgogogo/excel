# ERP计算系统
此项目缘于一位老师不想自己的Excel关于ERP的计算文件暴露给学生，此Excel文件有大量的公式。用JAVA开发了写入和读取excel文件，难点在于读取后的数据是Excel的计算完的结果。

## 相关技术
- 利用PIO工具调用excel文件进行静态计算
- 使用springmvc，json文件存储信息等技术 

## 部署环境
- jdk 1.8
- tomcat 8.5




